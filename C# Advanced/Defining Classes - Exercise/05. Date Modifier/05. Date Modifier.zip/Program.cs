﻿using System;

namespace _05._Date_Modifier
{
    public class Program
    {
        static void Main(string[] args)
        {
            DateModifier dm = new DateModifier();
            Console.WriteLine(dm.getDifference("1992 05 31", "2016 06 17"));
        }
    }
}
