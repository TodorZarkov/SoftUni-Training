﻿namespace Library.MessageConstants
{
    public static class ValidationMessages
    {
        public const string InvalidCategoryId = "Invalid Category.";
    }
}
