﻿namespace Library.Models.Category
{
    public class SelectCategoryDto
    {
        public int Id { get; set; }

        public string Name { get; set; } = null!;
    }
}
